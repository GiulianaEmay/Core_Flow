import { useState } from "react";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";
import axios from "axios";
import { SearchPanel } from "@/components/SearchPanel";
import { ResultsView } from "@/components/ResultsView";
import { LoadingView } from "@/components/LoadingView";
import { EmptyState } from "@/components/EmptyState";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import "@/App.css";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function App() {
  const [ruc, setRuc] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const handleSearch = async (rucValue) => {
    setError(null);
    setData(null);
    setLoading(true);
    try {
      const response = await axios.get(`${API}/consulta/${rucValue}`);
      const result = response.data;
      if (result.estadoConsulta === "not_found") {
        setError(result.mensaje || "No se encontró información para el RUC ingresado.");
        toast.error(result.mensaje);
      } else if (result.estadoConsulta === "blocked") {
        setError(result.mensaje || "La consulta requiere validación manual.");
        toast.error(result.mensaje);
      } else if (result.estadoConsulta === "error") {
        setError(result.mensaje || "SUNAT no está disponible temporalmente. Intente nuevamente.");
        toast.error(result.mensaje);
      } else {
        setData(result);
        toast.success("Información encontrada correctamente.");
      }
    } catch (err) {
      const status = err?.response?.status;
      const detail = err?.response?.data?.detail || err?.response?.data?.mensaje;
      let msg;
      if (status === 429) {
        msg = "Has excedido el límite de 10 consultas por minuto. Intenta más tarde.";
      } else if (status === 400) {
        msg = detail || "RUC inválido.";
      } else if (status === 502) {
        msg = "SUNAT no está disponible temporalmente. Intente nuevamente.";
      } else {
        msg = detail || "Ocurrió un error al consultar. Intenta nuevamente.";
      }
      setError(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setRuc("");
    setData(null);
    setError(null);
  };

  return (
    <div className="app-shell min-h-screen flex flex-col bg-slate-50">
      <Header />
      <main className="flex-1 w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
          <SearchPanel
            ruc={ruc}
            setRuc={setRuc}
            onSearch={handleSearch}
            onReset={handleReset}
            loading={loading}
            hasResult={!!data}
          />

          <div className="mt-8">
            {loading && <LoadingView />}
            {!loading && error && (
              <EmptyState
                variant="error"
                title="No se pudo completar la consulta"
                description={error}
              />
            )}
            {!loading && !error && !data && <EmptyState variant="idle" />}
            {!loading && !error && data && <ResultsView data={data} />}
          </div>
        </div>
      </main>
      <Footer />
      <Toaster position="top-right" richColors closeButton />
    </div>
  );
}

export default App;
