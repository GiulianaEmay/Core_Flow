import { CheckCircle2, AlertCircle, XCircle, Info } from "lucide-react";

const STATUS_CONFIG = {
  ok: {
    icon: CheckCircle2,
    color: "text-emerald-600",
    bg: "bg-emerald-50",
    border: "border-emerald-200",
    label: "Información encontrada.",
  },
  empty: {
    icon: Info,
    color: "text-slate-500",
    bg: "bg-slate-50",
    border: "border-slate-200",
    label: "No se encontró información registrada en SUNAT para este módulo.",
  },
  error: {
    icon: XCircle,
    color: "text-rose-600",
    bg: "bg-rose-50",
    border: "border-rose-200",
    label: "No se pudo cargar este módulo.",
  },
  not_available: {
    icon: AlertCircle,
    color: "text-amber-600",
    bg: "bg-amber-50",
    border: "border-amber-200",
    label: "Información no disponible públicamente.",
  },
};

export const ModuleStatus = ({ status, customMessage, testId }) => {
  const config = STATUS_CONFIG[status] || STATUS_CONFIG.error;
  const Icon = config.icon;
  return (
    <div
      className={`flex items-start gap-2.5 px-3 py-2 rounded-md ${config.bg} ${config.border} border text-xs`}
      data-testid={testId || "module-status"}
    >
      <Icon className={`w-4 h-4 mt-0.5 flex-shrink-0 ${config.color}`} />
      <span className={`${config.color} font-medium leading-relaxed`}>
        {customMessage || config.label}
      </span>
    </div>
  );
};

export const EmptyModule = ({ status, customMessage, title }) => {
  const config = STATUS_CONFIG[status] || STATUS_CONFIG.error;
  const Icon = config.icon;
  return (
    <div className="py-12 text-center" data-testid={`empty-module-${status}`}>
      <div
        className={`w-12 h-12 rounded-full ${config.bg} ${config.border} border mx-auto flex items-center justify-center mb-3`}
      >
        <Icon className={`w-5 h-5 ${config.color}`} />
      </div>
      {title && <p className="font-medium text-slate-800 text-sm mb-1">{title}</p>}
      <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
        {customMessage || config.label}
      </p>
    </div>
  );
};
