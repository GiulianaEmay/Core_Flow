import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ModuleStatus, EmptyModule } from "./ModuleStatus";

export const EstablecimientosTable = ({ module }) => {
  const items = module?.items || [];
  const status = module?.estado || "error";

  if (status !== "ok" || items.length === 0) {
    return <EmptyModule status={status} title="Establecimientos Anexos" />;
  }

  return (
    <div className="space-y-4" data-testid="anexos-table">
      <ModuleStatus status="ok" testId="anexos-status" />
      <div className="overflow-x-auto rounded-lg border border-slate-200">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50 hover:bg-slate-50">
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Código</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Tipo</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Dirección</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Departamento</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Provincia</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Distrito</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Estado</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((e, idx) => (
              <TableRow key={idx} className="hover:bg-slate-50/50">
                <TableCell className="text-sm font-mono-tabular">{e.codigo}</TableCell>
                <TableCell className="text-sm">{e.tipoEstablecimiento}</TableCell>
                <TableCell className="text-sm font-medium text-slate-900 max-w-xs">
                  {e.direccion}
                </TableCell>
                <TableCell className="text-sm">{e.departamento}</TableCell>
                <TableCell className="text-sm">{e.provincia}</TableCell>
                <TableCell className="text-sm">{e.distrito}</TableCell>
                <TableCell className="text-sm">
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    {e.estado}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
