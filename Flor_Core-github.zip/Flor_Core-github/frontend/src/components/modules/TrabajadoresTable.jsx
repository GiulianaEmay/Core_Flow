import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ModuleStatus, EmptyModule } from "./ModuleStatus";

export const TrabajadoresTable = ({ module }) => {
  const items = module?.items || [];
  const status = module?.estado || "error";

  if (status !== "ok" || items.length === 0) {
    return <EmptyModule status={status} title="Cantidad de Trabajadores" />;
  }

  // Compute summary
  const latest = items[0];

  return (
    <div className="space-y-4" data-testid="trabajadores-table">
      <ModuleStatus status="ok" testId="trab-status" />

      {latest && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3" data-testid="trab-summary">
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
            <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Último período</p>
            <p className="text-base font-bold text-slate-900 font-mono-tabular mt-1">{latest.periodo}</p>
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-[10px] uppercase tracking-wider text-blue-600 font-semibold">Trabajadores</p>
            <p className="text-base font-bold text-blue-900 font-mono-tabular mt-1">{latest.trabajadores}</p>
          </div>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
            <p className="text-[10px] uppercase tracking-wider text-amber-700 font-semibold">Pensionistas</p>
            <p className="text-base font-bold text-amber-900 font-mono-tabular mt-1">{latest.pensionistas}</p>
          </div>
          <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3">
            <p className="text-[10px] uppercase tracking-wider text-emerald-700 font-semibold">Prestadores</p>
            <p className="text-base font-bold text-emerald-900 font-mono-tabular mt-1">{latest.prestadoresServicio}</p>
          </div>
        </div>
      )}

      <div className="overflow-x-auto rounded-lg border border-slate-200">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50 hover:bg-slate-50">
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">Período</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold text-right">Trabajadores</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold text-right">Pensionistas</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold text-right">Prestadores Servicio</TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold text-right">Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((t, idx) => (
              <TableRow key={idx} className="hover:bg-slate-50/50">
                <TableCell className="text-sm font-mono-tabular font-medium text-slate-900">{t.periodo}</TableCell>
                <TableCell className="text-sm font-mono-tabular text-right">{t.trabajadores}</TableCell>
                <TableCell className="text-sm font-mono-tabular text-right">{t.pensionistas}</TableCell>
                <TableCell className="text-sm font-mono-tabular text-right">{t.prestadoresServicio}</TableCell>
                <TableCell className="text-sm font-mono-tabular text-right font-semibold text-[#0033A0]">
                  {t.total ?? "—"}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
