import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ModuleStatus, EmptyModule } from "./ModuleStatus";

export const RepresentantesTable = ({ module }) => {
  const items = module?.items || [];
  const status = module?.estado || "error";

  if (status !== "ok" || items.length === 0) {
    return <EmptyModule status={status} title="Representantes Legales" />;
  }

  return (
    <div className="space-y-4" data-testid="representantes-table">
      <ModuleStatus status="ok" testId="repleg-status" />
      <div className="overflow-x-auto rounded-lg border border-slate-200">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50 hover:bg-slate-50">
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Tipo Documento
              </TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                N° Documento
              </TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Nombre Completo
              </TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Cargo
              </TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Fecha Desde
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((rep, idx) => (
              <TableRow key={idx} className="hover:bg-slate-50/50">
                <TableCell className="text-sm">{rep.tipoDocumento}</TableCell>
                <TableCell className="text-sm font-mono-tabular">{rep.numeroDocumento}</TableCell>
                <TableCell className="text-sm font-medium text-slate-900">{rep.nombre}</TableCell>
                <TableCell className="text-sm">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200">
                    {rep.cargo}
                  </span>
                </TableCell>
                <TableCell className="text-sm font-mono-tabular text-slate-600">
                  {rep.fechaDesde || "—"}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
