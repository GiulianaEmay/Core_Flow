import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ModuleStatus, EmptyModule } from "./ModuleStatus";
import { AlertTriangle } from "lucide-react";

const formatMonto = (m) => {
  if (m === null || m === undefined || m === "") return "—";
  const n = parseFloat(String(m).replace(/,/g, ""));
  if (Number.isNaN(n)) return m;
  return n.toLocaleString("es-PE", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
};

export const DeudaCoactivaTable = ({ module }) => {
  const items = module?.items || [];
  const status = module?.estado || "error";

  if (status !== "ok" || items.length === 0) {
    return (
      <EmptyModule
        status={status}
        title="Deuda Coactiva"
        customMessage={
          module?.mensaje ||
          (status === "empty"
            ? "No se encontró deuda coactiva registrada en SUNAT."
            : undefined)
        }
      />
    );
  }

  const totalDeuda = items.reduce((acc, d) => {
    const n = parseFloat(String(d.monto || "0").replace(/,/g, ""));
    return acc + (Number.isNaN(n) ? 0 : n);
  }, 0);

  return (
    <div className="space-y-4" data-testid="deuda-table">
      <ModuleStatus status="ok" testId="deuda-status" />

      {module.mensaje && (
        <div
          className="flex items-start gap-2.5 px-3 py-2.5 rounded-md bg-amber-50 border border-amber-200 text-xs text-amber-800 leading-relaxed"
          data-testid="deuda-aviso"
        >
          <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0 text-amber-600" />
          <span>{module.mensaje}</span>
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3" data-testid="deuda-summary">
        <div className="bg-rose-50 border border-rose-200 rounded-lg p-3">
          <p className="text-[10px] uppercase tracking-wider text-rose-700 font-semibold">
            Total Deudas
          </p>
          <p className="text-base font-bold text-rose-900 font-mono-tabular mt-1">
            {items.length}
          </p>
        </div>
        <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 col-span-2 sm:col-span-2">
          <p className="text-[10px] uppercase tracking-wider text-rose-700 font-semibold">
            Monto Total
          </p>
          <p className="text-base font-bold text-rose-900 font-mono-tabular mt-1">
            S/ {formatMonto(totalDeuda)}
          </p>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-slate-200">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50 hover:bg-slate-50">
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold text-right">
                Monto de la Deuda (S/)
              </TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Período Tributario
              </TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Fecha Inicio Cobranza Coactiva
              </TableHead>
              <TableHead className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                Entidad Asociada
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((d, idx) => (
              <TableRow key={idx} className="hover:bg-slate-50/50">
                <TableCell className="text-sm font-mono-tabular text-right font-semibold text-rose-700">
                  {formatMonto(d.monto)}
                </TableCell>
                <TableCell className="text-sm font-mono-tabular">{d.periodo || "—"}</TableCell>
                <TableCell className="text-sm font-mono-tabular text-slate-600">
                  {d.fechaInicioCobranza || "—"}
                </TableCell>
                <TableCell className="text-sm">{d.entidad || "—"}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
