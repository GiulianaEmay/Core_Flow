import { Building2, Search, AlertCircle } from "lucide-react";

export const EmptyState = ({ variant = "idle", title, description }) => {
  if (variant === "error") {
    return (
      <div
        className="bg-white border border-rose-200 rounded-xl p-8 sm:p-12 text-center"
        data-testid="empty-state-error"
      >
        <div className="w-12 h-12 rounded-full bg-rose-50 border border-rose-200 mx-auto flex items-center justify-center mb-4">
          <AlertCircle className="w-6 h-6 text-rose-600" />
        </div>
        <h3 className="font-display text-lg font-semibold text-slate-900 mb-1">
          {title || "Error al consultar"}
        </h3>
        <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
          {description || "Intenta nuevamente o verifica el RUC ingresado."}
        </p>
      </div>
    );
  }

  return (
    <div
      className="bg-white border border-dashed border-slate-300 rounded-xl p-12 sm:p-16 text-center"
      data-testid="empty-state-idle"
    >
      <div className="w-14 h-14 rounded-xl bg-slate-50 border border-slate-200 mx-auto flex items-center justify-center mb-5">
        <Building2 className="w-7 h-7 text-slate-400" strokeWidth={1.5} />
      </div>
      <h3 className="font-display text-xl font-semibold text-slate-900 mb-2">
        Consulta información pública de un RUC
      </h3>
      <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
        Ingresa un número de RUC válido para ver la ficha principal, representantes legales,
        establecimientos anexos y más información del contribuyente.
      </p>
      <div className="mt-6 inline-flex items-center gap-2 text-xs text-slate-400">
        <Search className="w-3.5 h-3.5" />
        <span>Prueba con 20131312955 (SUNAT) o 20100070970 (Backus)</span>
      </div>
    </div>
  );
};
