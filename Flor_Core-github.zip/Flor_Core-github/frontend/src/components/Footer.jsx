export const Footer = () => {
  return (
    <footer className="border-t border-slate-200 bg-white mt-12" data-testid="app-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-500">
          <p className="max-w-3xl leading-relaxed" data-testid="legal-disclaimer">
            La información mostrada proviene de la consulta pública de SUNAT.
            Esta plataforma <strong className="text-slate-700">no emite certificados oficiales</strong>.
          </p>
          <p className="whitespace-nowrap">
            © {new Date().getFullYear()} · Consulta RUC SUNAT
          </p>
        </div>
      </div>
    </footer>
  );
};
