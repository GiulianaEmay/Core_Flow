import { ShieldCheck, Clock } from "lucide-react";

export const Header = () => {
  const now = new Date();
  const dateStr = now.toLocaleDateString("es-PE", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <header
      className="bg-white border-b border-slate-200 header-texture"
      data-testid="app-header"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-md bg-[#0033A0] flex items-center justify-center shadow-sm">
              <ShieldCheck className="w-5 h-5 text-white" strokeWidth={2.25} />
            </div>
            <div>
              <h1
                className="font-display text-xl sm:text-2xl font-bold text-slate-900 tracking-tight"
                data-testid="app-title"
              >
                Consulta RUC SUNAT
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Plataforma de consulta de información pública del contribuyente
              </p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500 px-3 py-1.5 rounded-md bg-slate-50 border border-slate-200">
            <Clock className="w-3.5 h-3.5" />
            <span className="capitalize">{dateStr}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
