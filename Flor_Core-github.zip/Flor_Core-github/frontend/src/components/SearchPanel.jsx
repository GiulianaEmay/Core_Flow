import { useState } from "react";
import { Search, RotateCcw, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const SearchPanel = ({ ruc, setRuc, onSearch, onReset, loading, hasResult }) => {
  const [touched, setTouched] = useState(false);

  const isValid = /^\d{11}$/.test(ruc);
  const showError = touched && ruc.length > 0 && !isValid;

  const handleChange = (e) => {
    // Only digits, max 11
    const value = e.target.value.replace(/\D/g, "").slice(0, 11);
    setRuc(value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setTouched(true);
    if (isValid && !loading) onSearch(ruc);
  };

  const handleReset = () => {
    setTouched(false);
    onReset();
  };

  return (
    <section
      className="bg-white border border-slate-200 rounded-xl p-5 sm:p-7 shadow-sm"
      data-testid="search-panel"
    >
      <div className="flex flex-col gap-1 mb-5">
        <h2 className="font-display text-lg sm:text-xl font-semibold text-slate-900">
          Buscar contribuyente
        </h2>
        <p className="text-xs sm:text-sm text-slate-500">
          Ingresa el número de RUC de 11 dígitos para consultar la información oficial de SUNAT.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-start">
        <div className="flex-1 max-w-xl">
          <label htmlFor="ruc-input" className="sr-only">
            Número de RUC
          </label>
          <Input
            id="ruc-input"
            data-testid="ruc-input"
            type="text"
            inputMode="numeric"
            autoComplete="off"
            placeholder="Ej. 20131312955"
            value={ruc}
            onChange={handleChange}
            onBlur={() => setTouched(true)}
            disabled={loading}
            className="h-12 text-base sm:text-lg border-slate-300 rounded-md focus-visible:ring-2 focus-visible:ring-[#0033A0] focus-visible:border-[#0033A0] font-mono-tabular tracking-wider"
            maxLength={11}
            aria-invalid={showError}
          />
          <div className="mt-1.5 flex items-center justify-between text-xs">
            <span
              className={showError ? "text-rose-600" : "text-slate-400"}
              data-testid="ruc-input-help"
            >
              {showError
                ? "El RUC debe tener exactamente 11 dígitos numéricos."
                : "11 dígitos · solo números"}
            </span>
            <span className="text-slate-400 font-mono-tabular">{ruc.length} / 11</span>
          </div>
        </div>

        <Button
          type="submit"
          disabled={!isValid || loading}
          data-testid="consultar-btn"
          className="h-12 px-7 bg-[#0033A0] hover:bg-[#002277] text-white font-medium rounded-md transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Consultando…
            </>
          ) : (
            <>
              <Search className="w-4 h-4" />
              Consultar
            </>
          )}
        </Button>

        {hasResult && !loading && (
          <Button
            type="button"
            onClick={handleReset}
            data-testid="nueva-consulta-btn"
            variant="outline"
            className="h-12 px-5 border-slate-300 hover:bg-slate-50 text-slate-700 rounded-md flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Nueva consulta
          </Button>
        )}
      </form>
    </section>
  );
};
