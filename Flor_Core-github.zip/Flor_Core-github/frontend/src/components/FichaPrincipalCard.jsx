import { Copy, Clock, CheckCircle2, AlertTriangle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const FIELDS = [
  { key: "numeroRuc", label: "Número de RUC" },
  { key: "tipoContribuyente", label: "Tipo de Contribuyente" },
  { key: "nombreComercial", label: "Nombre Comercial" },
  { key: "fechaInscripcion", label: "Fecha de Inscripción" },
  { key: "fechaInicioActividades", label: "Fecha Inicio Actividades" },
  { key: "actividadEconomica", label: "Actividad Económica" },
  { key: "domicilioFiscal", label: "Domicilio Fiscal" },
  { key: "departamento", label: "Departamento" },
  { key: "provincia", label: "Provincia" },
  { key: "distrito", label: "Distrito" },
  { key: "sistemaEmisionComprobante", label: "Sistema de Emisión" },
  { key: "sistemaContabilidad", label: "Sistema de Contabilidad" },
  { key: "actividadComercioExterior", label: "Comercio Exterior" },
  { key: "comprobantesPago", label: "Comprobantes de Pago" },
  { key: "sistemaEmisionElectronica", label: "Emisión Electrónica" },
  { key: "esAgenteRetencion", label: "Agente de Retención" },
  { key: "esBuenContribuyente", label: "Buen Contribuyente" },
];

const POSITIVE_ESTADOS = ["ACTIVO"];
const NEGATIVE_ESTADOS = ["BAJA DE OFICIO", "BAJA DEFINITIVA", "BAJA PROVISIONAL", "SUSPENSION TEMPORAL"];
const POSITIVE_CONDICIONES = ["HABIDO"];
const NEGATIVE_CONDICIONES = ["NO HABIDO", "NO HALLADO", "PENDIENTE"];

const classifyBadge = (value, positives, negatives) => {
  if (!value) return "neutral";
  const v = value.toUpperCase();
  if (positives.some((p) => v.includes(p))) return "success";
  if (negatives.some((n) => v.includes(n))) return "danger";
  return "warning";
};

const BadgeStatus = ({ label, value, kind }) => {
  const styles = {
    success: { bg: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-700", dot: "bg-emerald-500" },
    danger: { bg: "bg-rose-50", border: "border-rose-200", text: "text-rose-700", dot: "bg-rose-500" },
    warning: { bg: "bg-amber-50", border: "border-amber-200", text: "text-amber-700", dot: "bg-amber-500" },
    neutral: { bg: "bg-slate-50", border: "border-slate-200", text: "text-slate-600", dot: "bg-slate-400" },
  }[kind];
  const Icon = kind === "success" ? CheckCircle2 : kind === "danger" ? XCircle : AlertTriangle;
  return (
    <div
      className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-semibold ${styles.bg} ${styles.border} ${styles.text}`}
      data-testid={`badge-${label.toLowerCase()}`}
    >
      <span className={`semaphore-dot ${styles.dot}`} aria-hidden />
      <Icon className="w-3.5 h-3.5" />
      <span className="uppercase tracking-wide">{label}: {value || "—"}</span>
    </div>
  );
};

export const FichaPrincipalCard = ({ data }) => {
  const ficha = data.fichaPrincipal || {};
  const estadoKind = classifyBadge(ficha.estadoContribuyente, POSITIVE_ESTADOS, NEGATIVE_ESTADOS);
  const condicionKind = classifyBadge(ficha.condicionContribuyente, POSITIVE_CONDICIONES, NEGATIVE_CONDICIONES);

  const handleCopy = async () => {
    try {
      const text = [
        `Consulta RUC SUNAT — ${new Date(data.fechaHoraConsulta).toLocaleString("es-PE")}`,
        "",
        `RUC: ${ficha.numeroRuc}`,
        `Razón Social: ${data.razonSocial}`,
        `Estado: ${ficha.estadoContribuyente}`,
        `Condición: ${ficha.condicionContribuyente}`,
        ...FIELDS.map((f) => `${f.label}: ${ficha[f.key] || "-"}`),
      ].join("\n");
      await navigator.clipboard.writeText(text);
      toast.success("Datos copiados al portapapeles");
    } catch (err) {
      toast.error("No se pudo copiar al portapapeles");
    }
  };

  const fechaHora = data.fechaHoraConsulta
    ? new Date(data.fechaHoraConsulta).toLocaleString("es-PE", {
        dateStyle: "medium",
        timeStyle: "short",
      })
    : "—";

  return (
    <section
      className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm"
      data-testid="ficha-principal-card"
    >
      <div className="p-5 sm:p-7 border-b border-slate-100">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-1">
              Ficha Principal del Contribuyente
            </p>
            <h2
              className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 break-words"
              data-testid="razon-social"
            >
              {data.razonSocial || "—"}
            </h2>
            <div className="mt-2 flex items-center gap-3 flex-wrap">
              <span className="ruc-display text-lg font-semibold text-[#0033A0]" data-testid="ficha-ruc">
                RUC {ficha.numeroRuc}
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-sm text-slate-600">{ficha.tipoContribuyente || "—"}</span>
            </div>
          </div>

          <div className="flex flex-col items-end gap-3">
            <Button
              type="button"
              onClick={handleCopy}
              variant="outline"
              className="h-9 px-4 border-slate-300 hover:bg-slate-50 text-slate-700 rounded-md text-sm flex items-center gap-2"
              data-testid="copy-btn"
            >
              <Copy className="w-3.5 h-3.5" />
              Copiar datos
            </Button>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              <Clock className="w-3 h-3" />
              <span>Consultado: {fechaHora}</span>
            </div>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap gap-2.5" data-testid="semaphore-row">
          <BadgeStatus label="Estado" value={ficha.estadoContribuyente} kind={estadoKind} />
          <BadgeStatus label="Condición" value={ficha.condicionContribuyente} kind={condicionKind} />
          {ficha.esBuenContribuyente === "SÍ" && (
            <BadgeStatus label="Buen Contribuyente" value="SÍ" kind="success" />
          )}
          {ficha.esAgenteRetencion === "SÍ" && (
            <BadgeStatus label="Agente Retención" value="SÍ" kind="warning" />
          )}
        </div>
      </div>

      <div className="ficha-grid">
        {FIELDS.map((field) => (
          <div key={field.key} className="ficha-cell" data-testid={`ficha-field-${field.key}`}>
            <span className="ficha-label">{field.label}</span>
            <span className="ficha-value">{ficha[field.key] || "—"}</span>
          </div>
        ))}
      </div>
    </section>
  );
};
