import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Receipt, MapPin, BriefcaseBusiness } from "lucide-react";
import { FichaPrincipalCard } from "@/components/FichaPrincipalCard";
import { RepresentantesTable } from "@/components/modules/RepresentantesTable";
import { DeudaCoactivaTable } from "@/components/modules/DeudaCoactivaTable";
import { EstablecimientosTable } from "@/components/modules/EstablecimientosTable";
import { TrabajadoresTable } from "@/components/modules/TrabajadoresTable";

const TABS = [
  { id: "representantes", label: "Representantes Legales", icon: Users, count: (d) => d.representantesLegales?.items?.length || 0 },
  { id: "deuda", label: "Deuda Coactiva", icon: Receipt, count: (d) => d.deudaCoactiva?.items?.length || 0 },
  { id: "anexos", label: "Establecimientos Anexos", icon: MapPin, count: (d) => d.establecimientosAnexos?.items?.length || 0 },
  { id: "trabajadores", label: "Trabajadores y Prestadores", icon: BriefcaseBusiness, count: (d) => d.trabajadoresPrestadores?.items?.length || 0 },
];

export const ResultsView = ({ data }) => {
  const [tab, setTab] = useState("representantes");

  return (
    <div className="space-y-6 fade-in-up" data-testid="results-view">
      <FichaPrincipalCard data={data} />

      <section
        className="bg-white border border-slate-200 rounded-xl overflow-hidden"
        data-testid="modules-section"
      >
        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <div className="border-b border-slate-200 bg-slate-50/60 px-3 sm:px-5 py-3 overflow-x-auto hide-scrollbar">
            <TabsList className="bg-slate-100 p-1 rounded-lg inline-flex w-auto min-w-full sm:min-w-0">
              {TABS.map((t) => {
                const Icon = t.icon;
                const count = t.count(data);
                return (
                  <TabsTrigger
                    key={t.id}
                    value={t.id}
                    className="tab-trigger data-[state=active]:bg-white data-[state=active]:text-[#0033A0] data-[state=active]:shadow-sm text-slate-600 px-3 sm:px-4 py-2 rounded-md text-xs sm:text-sm font-medium transition-all whitespace-nowrap flex items-center gap-2"
                    data-testid={`tab-${t.id}`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{t.label}</span>
                    {count > 0 && (
                      <span className="ml-1 inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1.5 rounded-full bg-slate-200 text-slate-700 text-[10px] font-semibold">
                        {count}
                      </span>
                    )}
                  </TabsTrigger>
                );
              })}
            </TabsList>
          </div>

          <div className="p-4 sm:p-6">
            <TabsContent value="representantes" className="mt-0">
              <RepresentantesTable module={data.representantesLegales} />
            </TabsContent>
            <TabsContent value="deuda" className="mt-0">
              <DeudaCoactivaTable module={data.deudaCoactiva} />
            </TabsContent>
            <TabsContent value="anexos" className="mt-0">
              <EstablecimientosTable module={data.establecimientosAnexos} />
            </TabsContent>
            <TabsContent value="trabajadores" className="mt-0">
              <TrabajadoresTable module={data.trabajadoresPrestadores} />
            </TabsContent>
          </div>
        </Tabs>
      </section>
    </div>
  );
};
