export const LoadingView = () => {
  return (
    <div className="space-y-6 fade-in-up" data-testid="loading-view">
      {/* Main card skeleton */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div className="space-y-3 flex-1 min-w-0">
              <div className="h-3 w-24 skeleton-shimmer rounded" />
              <div className="h-8 w-72 skeleton-shimmer rounded" />
              <div className="h-4 w-48 skeleton-shimmer rounded" />
            </div>
            <div className="flex gap-2">
              <div className="h-7 w-24 skeleton-shimmer rounded-full" />
              <div className="h-7 w-24 skeleton-shimmer rounded-full" />
            </div>
          </div>
        </div>
        <div className="ficha-grid">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className="ficha-cell">
              <div className="h-3 w-20 skeleton-shimmer rounded" />
              <div className="h-4 w-32 skeleton-shimmer rounded mt-1" />
            </div>
          ))}
        </div>
      </div>

      {/* Tabs skeleton */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex gap-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-9 w-32 skeleton-shimmer rounded-md" />
          ))}
        </div>
        <div className="space-y-2 pt-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-12 w-full skeleton-shimmer rounded" />
          ))}
        </div>
      </div>
    </div>
  );
};
