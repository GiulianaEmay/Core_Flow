"""Backend tests for Consulta RUC SUNAT API."""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://datos-sunat-online.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

VALID_RUC_1 = "20609304082"
VALID_RUC_2 = "20131312955"


@pytest.fixture(scope="module")
def client():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# ---- Validation tests ----
class TestValidation:
    def test_root(self, client):
        r = client.get(f"{API}/")
        assert r.status_code == 200
        assert "message" in r.json()

    def test_ruc_too_short(self, client):
        r = client.get(f"{API}/consulta/12345")
        assert r.status_code == 400

    def test_ruc_with_letters(self, client):
        r = client.get(f"{API}/consulta/2060930408A")
        assert r.status_code == 400

    def test_ruc_invalid_prefix(self, client):
        r = client.get(f"{API}/consulta/30609304082")
        assert r.status_code == 400
        data = r.json()
        assert "detail" in data


# ---- Successful consult tests ----
class TestConsulta:
    def test_consulta_valid_ruc_1(self, client):
        r = client.get(f"{API}/consulta/{VALID_RUC_1}", timeout=60)
        assert r.status_code == 200, f"Body: {r.text[:500]}"
        d = r.json()
        # Top-level fields
        for k in ["ruc", "razonSocial", "fichaPrincipal", "representantesLegales",
                  "deudaCoactiva", "establecimientosAnexos", "trabajadoresPrestadores",
                  "estadoConsulta", "fechaHoraConsulta"]:
            assert k in d, f"Missing key {k}"
        assert d["ruc"] == VALID_RUC_1
        assert d["estadoConsulta"] == "ok"
        # Ficha
        fp = d["fichaPrincipal"]
        for k in ["numeroRuc", "razonSocial", "tipoContribuyente",
                  "estadoContribuyente", "condicionContribuyente",
                  "domicilioFiscal", "actividadEconomica",
                  "sistemaEmisionComprobante", "sistemaContabilidad",
                  "actividadComercioExterior"]:
            assert k in fp, f"Missing ficha key {k}"
        assert fp["numeroRuc"] == VALID_RUC_1
        # Deuda Coactiva not available
        assert d["deudaCoactiva"]["estado"] == "not_available"
        assert "mensaje" in d["deudaCoactiva"]

    def test_consulta_valid_ruc_2_sunat(self, client):
        r = client.get(f"{API}/consulta/{VALID_RUC_2}", timeout=60)
        assert r.status_code == 200, f"Body: {r.text[:500]}"
        d = r.json()
        assert d["ruc"] == VALID_RUC_2
        assert d["estadoConsulta"] == "ok"
        fp = d["fichaPrincipal"]
        assert fp["estadoContribuyente"] == "ACTIVO"
        # Representantes legales structure
        repleg = d["representantesLegales"]
        assert repleg["estado"] in ["ok", "empty", "error"]
        if repleg["estado"] == "ok" and repleg["items"]:
            it = repleg["items"][0]
            for k in ["tipoDocumento", "numeroDocumento", "nombre", "cargo", "fechaDesde"]:
                assert k in it
        # Trabajadores
        trab = d["trabajadoresPrestadores"]
        assert trab["estado"] in ["ok", "empty", "error"]
        if trab["estado"] == "ok" and trab["items"]:
            it = trab["items"][0]
            for k in ["periodo", "trabajadores", "prestadoresServicio", "total"]:
                assert k in it


# ---- Rate limit test ----
class TestRateLimit:
    def test_rate_limit_exceeded(self, client):
        # Use a likely invalid (but well-formed) RUC to avoid load on Decolecta
        # Actually we need to hit a passing endpoint - the validation is before rate limit.
        # Limiter decorator wraps; per slowapi, it counts before the function executes.
        responses = []
        for _ in range(12):
            r = client.get(f"{API}/consulta/{VALID_RUC_1}")
            responses.append(r.status_code)
            if r.status_code == 429:
                break
        assert 429 in responses, f"Expected 429 in {responses}"
