from fastapi import FastAPI, APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
import os
import logging
from pathlib import Path
import re

from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

from sunat_service import consultar_ruc  # noqa: E402


def client_ip(request: Request) -> str:
    """Get real client IP, honoring X-Forwarded-For from Kubernetes ingress."""
    xff = request.headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip()
    return get_remote_address(request)


# Rate limiter: 10 requests per minute per IP
limiter = Limiter(key_func=client_ip, default_limits=[])

app = FastAPI(title="Consulta RUC SUNAT API")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

api_router = APIRouter(prefix="/api")

RUC_PATTERN = re.compile(r"^\d{11}$")


@api_router.get("/")
async def root():
    return {"message": "Consulta RUC SUNAT API"}


@api_router.get("/consulta/{ruc}")
@limiter.limit("10/minute")
async def consulta_ruc(request: Request, ruc: str):
    if not RUC_PATTERN.match(ruc):
        raise HTTPException(
            status_code=400,
            detail="RUC inválido. Debe contener exactamente 11 dígitos numéricos.",
        )

    if not ruc.startswith(("10", "15", "16", "17", "20")):
        raise HTTPException(
            status_code=400,
            detail="RUC inválido. Debe iniciar con 10, 15, 16, 17 o 20.",
        )

    try:
        result = await consultar_ruc(ruc)
    except Exception:
        logger.exception("Error al consultar RUC")
        return JSONResponse(
            status_code=502,
            content={
                "ruc": ruc,
                "estadoConsulta": "error",
                "mensaje": "SUNAT no está disponible temporalmente. Intente nuevamente.",
            },
        )

    logger.info(
        "Consulta RUC %s desde %s -> %s",
        ruc,
        client_ip(request),
        result.get("estadoConsulta"),
    )
    return result


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)
