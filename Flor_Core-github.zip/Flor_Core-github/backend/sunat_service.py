"""
SUNAT Consulta RUC service.
Combines Decolecta API (ficha principal + locales anexos) with SUNAT public POST endpoints
for representantes legales and cantidad de trabajadores.
"""
import os
import asyncio
import logging
import re
from datetime import datetime, timezone
from typing import Optional, Any

import httpx
from bs4 import BeautifulSoup
from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).parent / ".env")

logger = logging.getLogger(__name__)

DECOLECTA_TOKEN = os.environ.get("DECOLECTA_TOKEN", "")
DECOLECTA_URL = "https://api.decolecta.com/v1/sunat/ruc/full"
SUNAT_URL = "https://e-consultaruc.sunat.gob.pe/cl-ti-itmrconsruc/jcrS00Alias"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)


def _clean(text: Optional[str]) -> str:
    if not text:
        return ""
    return re.sub(r"\s+", " ", text).strip()


async def fetch_decolecta(ruc: str) -> dict[str, Any]:
    """Get ficha principal + locales anexos from Decolecta."""
    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.get(
            DECOLECTA_URL,
            params={"numero": ruc},
            headers={
                "Authorization": f"Bearer {DECOLECTA_TOKEN}",
                "Accept": "application/json",
            },
        )
        if resp.status_code == 404:
            return {"_error": "not_found"}
        if resp.status_code == 429:
            return {"_error": "rate_limit"}
        if resp.status_code >= 500:
            return {"_error": "sunat_unavailable"}
        resp.raise_for_status()
        return resp.json()


async def _sunat_post(action: str, ruc: str) -> Optional[str]:
    """Perform a POST to SUNAT and return decoded HTML body, or None on error."""
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            resp = await client.post(
                SUNAT_URL,
                content=f"accion={action}&nroRuc={ruc}&desRuc=&token=&tipdoc=1".encode(
                    "iso-8859-1"
                ),
                headers={
                    "Content-Type": "application/x-www-form-urlencoded; charset=ISO-8859-1",
                    "User-Agent": USER_AGENT,
                    "Accept": "text/html,application/xhtml+xml",
                },
            )
            if resp.status_code != 200:
                return None
            html = resp.content.decode("iso-8859-1", errors="replace")
            # Detect SUNAT error page
            if "Pagina de Error" in html or "P&aacute;gina de Error" in html:
                return None
            if len(html) < 200:
                return None
            return html
    except Exception as e:
        logger.warning(f"SUNAT POST {action} failed: {e}")
        return None


async def fetch_representantes(ruc: str) -> dict[str, Any]:
    """Get representantes legales via SUNAT POST."""
    html = await _sunat_post("getRepLeg", ruc)
    if html is None:
        return {"status": "error", "data": []}
    try:
        soup = BeautifulSoup(html, "lxml")
        table = soup.find("table", class_="table")
        if not table:
            return {"status": "empty", "data": []}
        rows = table.find_all("tr")
        results = []
        for tr in rows[1:]:  # skip header
            tds = tr.find_all("td")
            if len(tds) < 5:
                continue
            results.append(
                {
                    "tipoDocumento": _clean(tds[0].get_text()),
                    "numeroDocumento": _clean(tds[1].get_text()),
                    "nombre": _clean(tds[2].get_text()),
                    "cargo": _clean(tds[3].get_text()),
                    "fechaDesde": _clean(tds[4].get_text()),
                }
            )
        if not results:
            return {"status": "empty", "data": []}
        return {"status": "ok", "data": results}
    except Exception as e:
        logger.warning(f"Parse representantes failed: {e}")
        return {"status": "error", "data": []}


async def fetch_deuda_coactiva(ruc: str) -> dict[str, Any]:
    """Get deuda coactiva via SUNAT POST."""
    html = await _sunat_post("getInfoDC", ruc)
    if html is None:
        return {"status": "empty", "data": [], "mensaje": None}
    try:
        soup = BeautifulSoup(html, "lxml")
        # Extract update notice (first sentence about "actualizada al ...")
        mensaje = None
        full_text = soup.get_text()
        import re as _re
        m = _re.search(
            r"La información[^.]*actualizada[^.]*\.\s*[^.\n]*coactiva\.", full_text
        )
        if m:
            mensaje = _re.sub(r"\s+", " ", m.group(0)).strip()

        table = soup.find("table")
        if not table:
            return {"status": "empty", "data": [], "mensaje": mensaje}
        rows = table.find_all("tr")
        results = []
        for tr in rows[1:]:  # skip header
            tds = tr.find_all("td")
            if len(tds) < 4:
                continue
            monto = _clean(tds[0].get_text())
            periodo = _clean(tds[1].get_text())
            fecha = _clean(tds[2].get_text())
            entidad = _clean(tds[3].get_text())
            # Skip empty rows
            if not monto and not periodo:
                continue
            results.append(
                {
                    "monto": monto,
                    "periodo": periodo,
                    "fechaInicioCobranza": fecha,
                    "entidad": entidad,
                }
            )
        if not results:
            return {"status": "empty", "data": [], "mensaje": mensaje}
        return {"status": "ok", "data": results, "mensaje": mensaje}
    except Exception as e:
        logger.warning(f"Parse deuda coactiva failed: {e}")
        return {"status": "error", "data": [], "mensaje": None}


async def fetch_trabajadores(ruc: str) -> dict[str, Any]:
    """Get cantidad de trabajadores via SUNAT POST."""
    html = await _sunat_post("getCantTrab", ruc)
    if html is None:
        return {"status": "error", "data": []}
    try:
        soup = BeautifulSoup(html, "lxml")
        rows = soup.find_all("tr")
        results = []
        for tr in rows:
            tds = tr.find_all("td")
            if len(tds) != 4:
                continue
            periodo = _clean(tds[0].get_text())
            # Only rows with period like YYYY-MM
            if not re.match(r"^\d{4}-\d{2}$", periodo):
                continue
            trab = _clean(tds[1].get_text())
            pens = _clean(tds[2].get_text())
            prest = _clean(tds[3].get_text())
            try:
                total = int(trab or 0) + int(pens or 0) + int(prest or 0)
            except ValueError:
                total = None
            results.append(
                {
                    "periodo": periodo,
                    "trabajadores": trab,
                    "pensionistas": pens,
                    "prestadoresServicio": prest,
                    "total": total,
                }
            )
        if not results:
            return {"status": "empty", "data": []}
        # Most recent first
        results.sort(key=lambda x: x["periodo"], reverse=True)
        return {"status": "ok", "data": results}
    except Exception as e:
        logger.warning(f"Parse trabajadores failed: {e}")
        return {"status": "error", "data": []}


def _normalize_status(s: str) -> str:
    return _clean(s).upper()


def _map_ficha(d: dict[str, Any]) -> dict[str, str]:
    """Map decolecta response to fichaPrincipal structure."""
    return {
        "numeroRuc": d.get("numero_documento", "") or "",
        "razonSocial": d.get("razon_social", "") or "",
        "tipoContribuyente": d.get("tipo", "") or "",
        "nombreComercial": d.get("nombre_comercial", "") or "-",
        "fechaInscripcion": d.get("fecha_inscripcion", "") or "-",
        "fechaInicioActividades": d.get("fecha_inicio_actividades", "") or "-",
        "estadoContribuyente": _normalize_status(d.get("estado", "")),
        "condicionContribuyente": _normalize_status(d.get("condicion", "")),
        "domicilioFiscal": d.get("direccion_completa", "") or d.get("direccion", "") or "-",
        "departamento": d.get("departamento", "") or "-",
        "provincia": d.get("provincia", "") or "-",
        "distrito": d.get("distrito", "") or "-",
        "ubigeo": d.get("ubigeo", "") or "-",
        "sistemaEmisionComprobante": d.get("tipo_facturacion", "") or "-",
        "actividadComercioExterior": d.get("comercio_exterior", "") or "-",
        "sistemaContabilidad": d.get("tipo_contabilidad", "") or "-",
        "actividadEconomica": d.get("actividad_economica", "") or "-",
        "comprobantesPago": d.get("comprobantes_pago", "") or "-",
        "sistemaEmisionElectronica": d.get("sistema_emision_electronica", "") or "-",
        "esAgenteRetencion": "SÍ" if d.get("es_agente_retencion") else "NO",
        "esBuenContribuyente": "SÍ" if d.get("es_buen_contribuyente") else "NO",
    }


def _map_anexos(items: list[dict]) -> list[dict]:
    result = []
    for idx, item in enumerate(items or [], start=1):
        result.append(
            {
                "codigo": str(idx).zfill(4),
                "tipoEstablecimiento": item.get("tipo_establecimiento", "")
                or "LOCAL ANEXO",
                "direccion": item.get("direccion", "") or "-",
                "departamento": item.get("departamento", "") or "-",
                "provincia": item.get("provincia", "") or "-",
                "distrito": item.get("distrito", "") or "-",
                "estado": item.get("estado", "") or "ACTIVO",
            }
        )
    return result


async def consultar_ruc(ruc: str) -> dict[str, Any]:
    """Main entry point. Returns the full consulta structure."""
    # Run all queries concurrently
    decolecta_task = fetch_decolecta(ruc)
    repleg_task = fetch_representantes(ruc)
    trab_task = fetch_trabajadores(ruc)
    deuda_task = fetch_deuda_coactiva(ruc)

    decolecta_data, repleg, trab, deuda = await asyncio.gather(
        decolecta_task, repleg_task, trab_task, deuda_task, return_exceptions=True
    )

    fecha_hora = datetime.now(timezone.utc).isoformat()

    # Handle decolecta result
    if isinstance(decolecta_data, Exception):
        logger.error(f"Decolecta error: {decolecta_data}")
        return {
            "ruc": ruc,
            "estadoConsulta": "error",
            "mensaje": "SUNAT no está disponible temporalmente. Intente nuevamente.",
            "fechaHoraConsulta": fecha_hora,
        }

    if isinstance(decolecta_data, dict) and decolecta_data.get("_error"):
        err = decolecta_data["_error"]
        if err == "not_found":
            return {
                "ruc": ruc,
                "estadoConsulta": "not_found",
                "mensaje": "No se encontró información para el RUC ingresado.",
                "fechaHoraConsulta": fecha_hora,
            }
        if err == "rate_limit":
            return {
                "ruc": ruc,
                "estadoConsulta": "blocked",
                "mensaje": "La consulta requiere validación manual.",
                "fechaHoraConsulta": fecha_hora,
            }
        return {
            "ruc": ruc,
            "estadoConsulta": "error",
            "mensaje": "SUNAT no está disponible temporalmente. Intente nuevamente.",
            "fechaHoraConsulta": fecha_hora,
        }

    ficha = _map_ficha(decolecta_data)
    anexos = _map_anexos(decolecta_data.get("locales_anexos") or [])

    if isinstance(repleg, Exception):
        repleg = {"status": "error", "data": []}
    if isinstance(trab, Exception):
        trab = {"status": "error", "data": []}
    if isinstance(deuda, Exception):
        deuda = {"status": "error", "data": [], "mensaje": None}

    return {
        "ruc": ruc,
        "razonSocial": ficha.get("razonSocial", ""),
        "fichaPrincipal": ficha,
        "representantesLegales": {
            "estado": repleg["status"],
            "items": repleg["data"],
        },
        "deudaCoactiva": {
            "estado": deuda["status"],
            "items": deuda["data"],
            "mensaje": deuda.get("mensaje"),
        },
        "establecimientosAnexos": {
            "estado": "ok" if anexos else "empty",
            "items": anexos,
        },
        "trabajadoresPrestadores": {
            "estado": trab["status"],
            "items": trab["data"],
        },
        "estadoConsulta": "ok",
        "fechaHoraConsulta": fecha_hora,
    }
