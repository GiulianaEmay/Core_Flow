# Flor Core

Aplicacion full-stack para consultar informacion publica de SUNAT por RUC.

## Estructura

```text
Flor_Core/
  backend/    API FastAPI y servicio de consulta SUNAT/Decolecta
  frontend/   Aplicacion React
  memory/     Documentacion funcional del proyecto
  tests/      Paquete base de pruebas
```

## Importante para GitHub

Sube a GitHub el contenido de esta carpeta, no una carpeta que contenga otra `Flor_Core-main` adentro.

La raiz del repositorio debe mostrar directamente:

```text
backend/
frontend/
memory/
README.md
```

## Ejecutar en local

### Backend

1. Crea `backend/.env` usando `backend/.env.example` como referencia.
2. Instala dependencias:

```bash
cd backend
pip install -r requirements.txt
```

3. Inicia la API:

```bash
uvicorn server:app --host 0.0.0.0 --port 8000
```

La API queda disponible en:

```text
http://localhost:8000/api
```

### Frontend

1. Crea `frontend/.env` usando `frontend/.env.example` como referencia.
2. Instala dependencias:

```bash
cd frontend
npm install
```

3. Inicia React:

```bash
npm start
```

La app queda disponible en:

```text
http://localhost:3000
```

## Publicacion

GitHub por si solo no ejecuta el backend FastAPI. Para que la app funcione publicada:

- Publica el frontend como sitio estatico, por ejemplo GitHub Pages, Vercel o Netlify.
- Publica el backend en un servicio que ejecute Python/FastAPI, por ejemplo Render, Railway, Fly.io o un VPS.
- Configura `REACT_APP_BACKEND_URL` en el frontend con la URL publica del backend.

Si solo publicas el frontend sin backend, la pantalla puede cargar, pero las consultas RUC no funcionaran.
