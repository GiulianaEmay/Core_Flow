# Consulta RUC SUNAT - PRD

## Original Problem Statement
Aplicación full-stack para consultar información pública de SUNAT por RUC y mostrarla en pantalla (sin descargas, sin PDFs, sin ZIPs). 5 módulos: Ficha Principal, Representantes Legales, Deuda Coactiva, Establecimientos Anexos, Trabajadores/Prestadores.

## Architecture
- **Backend**: FastAPI + httpx + BeautifulSoup + slowapi (rate limit)
- **Frontend**: React + Shadcn UI + Tailwind + Sonner toasts + lucide-react icons
- **Fuentes de datos**:
  - Decolecta API (`api.decolecta.com/v1/sunat/ruc/full`) → ficha principal + establecimientos anexos
  - SUNAT POST público `jcrS00Alias` con accion=`getRepLeg` → representantes legales
  - SUNAT POST público `jcrS00Alias` con accion=`getCantTrab` → cantidad trabajadores por período
- **Database**: MongoDB (configurado pero no usado - sin logs persistentes según user choice)

## User Personas
- Empresarios, contadores, abogados, ciudadanos que necesitan validar contribuyentes peruanos.

## Core Requirements (Static)
1. Validación RUC: exactamente 11 dígitos numéricos, debe iniciar con 10/15/16/17/20
2. UI: header institucional, input con validación, botón Consultar, ficha principal grande, tabs para 4 módulos
3. Semáforo visual: verde (ACTIVO/HABIDO), amarillo (warning), rojo (BAJA/NO HABIDO)
4. Rate limit: 10 consultas/min por IP real (X-Forwarded-For)
5. Aviso legal en footer: "no emite certificados oficiales"

## Implemented (22-May-2026)
- ✅ Backend FastAPI con endpoint `GET /api/consulta/{ruc}` que integra Decolecta + SUNAT
- ✅ Rate limit 10/min por IP real usando X-Forwarded-For
- ✅ Validación de RUC con manejo de errores (400, 429, 502, not_found, blocked)
- ✅ Frontend con Header, SearchPanel, FichaPrincipalCard, ResultsView con 4 tabs
- ✅ Componentes de tabla para cada módulo (Representantes, Deuda, Anexos, Trabajadores)
- ✅ Botón "Copiar datos" y "Nueva consulta"
- ✅ Indicador fecha/hora de consulta
- ✅ Semáforo visual con dots pulsantes
- ✅ Fuentes Outfit + IBM Plex Sans, color institucional #0033A0
- ✅ Aviso legal en footer
- ✅ Toasts Sonner para feedback

## Backlog
### P1
- Persistir historial reciente local (localStorage) en frontend
- Caché temporal de consultas (Redis) para reducir llamadas a Decolecta/SUNAT
- Compartir resultado mediante link público (?ruc=...)

### P2
- Búsqueda por razón social (no solo RUC)
- Exportar resultados como vista imprimible (NO PDF download, solo print-friendly)
- Modo oscuro

### Limitaciones conocidas
- Deuda coactiva: SUNAT no expone esta data públicamente. Se muestra mensaje informativo.
- Decolecta plan gratuito tiene límites mensuales de consultas.

## Files
- `/app/backend/server.py` - FastAPI app + routing + rate limit
- `/app/backend/sunat_service.py` - Lógica de consulta combinada
- `/app/frontend/src/App.js` - Root component
- `/app/frontend/src/components/Header.jsx`
- `/app/frontend/src/components/Footer.jsx`
- `/app/frontend/src/components/SearchPanel.jsx`
- `/app/frontend/src/components/ResultsView.jsx`
- `/app/frontend/src/components/FichaPrincipalCard.jsx`
- `/app/frontend/src/components/LoadingView.jsx`
- `/app/frontend/src/components/EmptyState.jsx`
- `/app/frontend/src/components/modules/RepresentantesTable.jsx`
- `/app/frontend/src/components/modules/DeudaCoactivaTable.jsx`
- `/app/frontend/src/components/modules/EstablecimientosTable.jsx`
- `/app/frontend/src/components/modules/TrabajadoresTable.jsx`
- `/app/frontend/src/components/modules/ModuleStatus.jsx`
